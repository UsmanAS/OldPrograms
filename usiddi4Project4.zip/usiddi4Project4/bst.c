#include "bst.h"
#include <stdio.h>
#include <stdlib.h>
//Usman Siddiqui
struct bst_node {
    int val;
    struct bst_node *left;
    struct bst_node *right;
    int leftChildren;
    int rightChildren;

};
typedef struct bst_node NODE;


struct bst {
    NODE *root;
};

BST_PTR bst_create(){
  BST_PTR t = malloc(sizeof(struct bst));
  t->root = NULL;
  return t;
}


static void free_r(NODE *r){
    if(r==NULL) return;
    free_r(r->left);
    free_r(r->right);
    free(r);
}
void bst_free(BST_PTR t){
    free_r(t->root);
    free(t);
}

static NODE * insert(NODE *r, int x){
    NODE *leaf;
    if(r == NULL){
      leaf = malloc(sizeof(NODE));
      leaf->left = NULL;
      leaf->right = NULL;
      leaf->val = x;
      return leaf;
    }
    if(r->val == x)
        return r;
    if(x < r->val){
        r->left = insert(r->left, x);
        r->leftChildren++;		//Increment left children
        return r;
    }
    else {
        r->right = insert(r->right, x);
        r->rightChildren++;		//Increment right children
        return r;
    }
}

// how about an iterative version?
static NODE *insert_i(NODE *r, int x){

  return NULL;

}


void bst_insert(BST_PTR t, int x){
    t->root = insert(t->root, x);
}

int bst_contains(BST_PTR t, int x){
    NODE *p = t->root;

    while(p != NULL){

        if(p->val == x)
            return 1;
        if(x < p->val){
            p = p->left;
        }
        else
            p = p->right;
    }
    return 0;  
}

static int min_h(NODE *r){
  if(r==NULL)
    return -1; // should never happen!
  while(r->left != NULL)
      r = r->left;
  return r->val;
}

static int max_h(NODE *r){
  if(r==NULL)
    return -1; // should never happen!
  while(r->right != NULL)
      r = r->right;
  return r->val;
}

static NODE *remove_r(NODE *r, int x, int *success){
NODE   *tmp;
int sanity;

  if(r==NULL){
    *success = 0;
    return NULL;
  }
  if(r->val == x){
    *success = 1;

    if(r->left == NULL){
        tmp = r->right;
        free(r);
        tmp->rightChildren--;		//Decrement right children
        return tmp;
    }
    if(r->right == NULL){
        tmp = r->left;
        free(r);
        tmp->leftChildren--;		//Decrement left children
        return tmp;
    }
    // if we get here, r has two children
    r->val = min_h(r->right);
    r->right = remove_r(r->right, r->val, &sanity);
    if(!sanity)
        printf("ERROR:  remove() failed to delete promoted value?\n");
    return r;
  }
  if(x < r->val){
    r->left = remove_r(r->left, x, success);
  }
  else {
    r->right = remove_r(r->right, x, success);
  }
  return r;

}


int bst_remove(BST_PTR t, int x){
    int success;
    t->root = remove_r(t->root, x, &success);
    return success;
}
static int size(NODE *r){

    if(r==NULL) return 0;
    return r->rightChildren + r->leftChildren + 1;
    //return size(r->left) + size(r->right) + 1;
}
int bst_size(BST_PTR t){

    return size(t->root);
}

static int height(NODE *r){
    int l_h, r_h;

    if(r==NULL) return -1;
    l_h = height(r->left);
    r_h = height(r->right);
    return 1 + (l_h > r_h ? l_h : r_h);

}
int bst_height(BST_PTR t){
    return height(t->root);

}

int bst_min(BST_PTR t){
    return min_h(t->root);
}

int bst_max(BST_PTR t){
    return max_h(t->root);
}

static void indent(int m){
    int i;
    for(i=0; i<m; i++)
        printf("-");
}

static void inorder(NODE *r){
  if(r==NULL) return;
  inorder(r->left);
  printf("[%d]\n", r->val);
  inorder(r->right);

}
void bst_inorder(BST_PTR t){

  printf("========BEGIN INORDER============\n");
  inorder(t->root);
  printf("=========END INORDER============\n");

}

static void preorder(NODE *r, int margin){
  if(r==NULL) {
    indent(margin);
    printf("NULL \n");
  } else {
    indent(margin);
    printf("%d\n", r->val);
    preorder(r->left, margin+3);
    preorder(r->right, margin+3);
  }
}

void bst_preorder(BST_PTR t){

  printf("========BEGIN PREORDER============\n");
  preorder(t->root, 0);
  printf("=========END PREORDER============\n");

}

/* 
 * Not a graded exercise, but good practice!
 *
 * Complete the (recursive) helper function for the post-order traversal.
 * Remember: the indentation needs to be proportional to the height of the node!
 */
static void postorder(NODE *r, int margin){
    /* FILL IN FUNCTION */
}

// indentation is proportional to depth of node being printed
//   depth is #hops from root.
void bst_postorder(BST_PTR t){

  printf("========BEGIN POSTORDER============\n");
  postorder(t->root, 0);
  printf("=========END POSTORDER============\n");

}

/* 
 * Recursive helper function from_arr, used by
 * bst_from_sorted_arr(...). The function must return a sub-tree that is
 * perfectly balanced, given a sorted array of elements a.
 */
static NODE * from_arr(int *a, int n){
int m;
NODE *root;

    if(n <= 0) return NULL;
    m = n/2;
    root = malloc(sizeof(NODE));
    root->val = a[m];
    root->left = from_arr(a, m);
    root->right = from_arr(&(a[m+1]), n-(m+1));
    return root;

}

BST_PTR bst_from_sorted_arr(int *a, int n){

  BST_PTR t = bst_create();

  t->root = from_arr(a, n);

  return t;
}


/******    TODO      *********/

int * bst_to_array(BST_PTR t) {
  int size = bst_size(t);
  int* arr = malloc(sizeof(int) * size);
  NODE* ptr = t->root;

  if( arr == NULL)
	return arr;
  if( size == 1)
	{
		arr[0] = ptr->val;
		return arr;
	}
  int i = 0;
  NODE* tmp = ptr;
  
  while(tmp->left != NULL)
  {
	if(tmp->left->left == NULL)
	{
		arr[i] = tmp->left->val;
		arr[i+1] = tmp->val;
		i += 2;
		if(tmp->left->right == NULL)
		{
			tmp->left = NULL;
		}

		else if(tmp->left->right->left == NULL && tmp->left->right->right == NULL)
		{
			i++;
			arr[i] = tmp->left->right->val;
			tmp->left = NULL;
		}

		else
		{
			tmp = tmp->left->right;
		}				
	}

	else
		tmp = tmp->left;
  }
  return arr;

}

int bst_get_ith(BST_PTR t, int i) {
  int size = bst_size(t);
  if(i > size)
  {
	fprintf(stderr, "Error out of range.\n");
	return -1;
  }
  return 0;

}
int bst_get_nearest_r(NODE * r, int x)
{
NODE   *tmp = r;
int ans;
  if(tmp==NULL){
    return -1;
  }
  if(tmp->val > x && ((tmp->val - x) == 1))
	return tmp->val;
  if(tmp->val < x && ((x - tmp->val) == 1))
	return tmp->val;
  if(tmp->val == x){
    if(tmp->left == NULL){
        return tmp->right->val;
    }
    if(tmp->right == NULL){
        return tmp->left->val;
    }
    // if we get here, tmp has two children return the closer child or just the smaller if the gap is the same
    int left = tmp->val - tmp->left->val;
    int right = tmp->right->val - tmp->val;
    if(right < left)
	return tmp->right->val;
    return tmp->left->val;
  }
  if(x < tmp->val){
    ans = bst_get_nearest_r(tmp->left, x);
  }
  else {
    ans = bst_get_nearest_r(tmp->right, x);
  }
  return ans;

}
int bst_get_nearest(BST_PTR t, int x) {

  NODE *tmp = t->root;
  if(tmp == NULL)
  {
	fprintf(stderr, "Error tree empty.\n");
	return -1;
  }
  int ans = bst_get_nearest_r(tmp, x);

  return ans;

}

int bst_num_geq_r(NODE* ptr, int x)
{
  if(ptr == NULL)
	return 0;
  if(x == ptr->val)
	return ptr->rightChildren;
  if(x < ptr->val)
	return ptr->rightChildren + bst_num_geq_r(ptr->left, x) + 1;
  if(x > ptr->val)
	return bst_num_geq_r(ptr->right,x);
  return 0;
}

int bst_num_geq(BST_PTR t, int x) {
  NODE* ptr = t->root;
  int ans = 0;
  if(x == ptr->val)
	return ptr->rightChildren;
  ans = bst_num_geq_r(ptr, x);
  return ans;

}

static int bst_num_leq_r(NODE* ptr, int x)
{
  if(ptr == NULL)
	return 0;
  if(x == ptr->val)
	return ptr->leftChildren;
  if(x < ptr->val)
	return bst_num_leq_r(ptr->left, x);
  if(x > ptr->val)
	return bst_num_leq_r(ptr->right,x) + ptr->leftChildren + 1;
  return 0;
}

int bst_num_leq(BST_PTR t, int x) {
  NODE* ptr = t->root;
  int ans;
  if(x == ptr->val)
	return ptr->leftChildren;
  ans = bst_num_leq_r(ptr, x);
  return ans;
}

