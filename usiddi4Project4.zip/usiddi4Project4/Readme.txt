


Name:Usman Siddiqui	CS 251 Spring 2016
usiddi4@uic.edu
656767554
-----------------------------------------------

Describe what augmentations to the bst data structures you made to complete the 
project -- i.e., what typedefs did you change and why?

I added 2 new parts to the struct, both are integers which contain the number of left children and right children and are labled as such.
I did this in order to have size be O(1) since size is now left children + right children + 1(for the parent/root).


-----------------------------------------------
Which functions did you need to modify as a result of the augmentations from the previous
question?  

The insert function I added 2 lines to increment the left children whenever a node to the left was added and same but for the right children.
Also the remove function I added 2 lines again to decrement, these lines have comments.



-----------------------------------------------
For each function from the previous question, how did you ensure that the (assymptotic) runtime 
remained the same?

I didn't really ensure it, all I did was add 2 lines that do constant time operations so the runtime shouldn't change.



-----------------------------------------------
For each of the assigned functions, tell us how far you got using the choices 0-5 and
answer the given questions.  


0:  didn't get started
1:  started, but far from working
2:  have implementation but only works for simple cases
3:  finished and I think it works most of the time but not sure the runtime req is met. 
4:  finished and I think it works most of the time and I'm sure my design leads to 
       the correct runtime (even if I still have a few bugs).
5:  finished and confident on correctness and runtime requirements


bst_to_array level of completion:  1 


-----------------------------------------------
bst_get_ith level of completion:  0  

    How did you ensure O(h) runtime?

    ANSWER:

-----------------------------------------------
bst_get_nearest level of completion:  4  

    How did you ensure O(h) runtime? 

    ANSWER: Looked into how deep into the tree the program would go, and it would only go up until it finds the node
	    or it might even stop before that. It goes to check its parents first then checks its children to find the closest
	    possible match, so it should be O(h).
  
-----------------------------------------------
bst_num_geq level of completion:  5  

    How did you ensure O(h) runtime?

    ANSWER: It moves through the tree until it hits the number, or it hits a null. This means it is O(h) and to make sure it achieved it I
	    only used constant time operations which were adding up the children in some cases and then adding 1. So if it the number
	    was less than the current node it would recursively go into the next one until the end and then add up all the right children
	    of each node going back up until the root, would also add 1 for every level to account for the parent nodes. If it is greater then
	    it recursively calls itself until it finds the number or hits a null.

-----------------------------------------------
bst_num_leq level of completion:  5

    How did you ensure O(h) runtime?

    ANSWER: Almost the same as bst_num_geq, biggest difference is if its greater than the current node it recursively calls and adds all the left children.
	    If it is less than the current node it keeps calling itself till it finds the number or hits a null.

-----------------------------------------------
EXTRA CREDIT FUNCTIONS:

bst_min level of completion:  0

    How did you ensure O(1) runtime?

    ANSWER:

-----------------------------------------------
bst_max level of completion:  0

    How did you ensure O(1) runtime?

    ANSWER:

----------------------------------------------

Write a few sentences describing how you tested your solutions.  Are there
any tests that in retrospect you wish you'd done?

I just tested small cases, was too tired to test bigger cases which I guess I wish I had started earlier to test them, but I'm falling
behind in other classes so I need to focus on those more.


