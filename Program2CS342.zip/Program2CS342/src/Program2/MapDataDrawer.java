package Program2;

import java.util.*;


import java.io.*;
import java.awt.*;

public class MapDataDrawer
{

  private int[][] grid;

  public MapDataDrawer(String filename)
  {

	  
	  try (BufferedReader br = new BufferedReader(new FileReader(filename)))// Set up br to have the text file in it
	  {
		  Scanner sc = new Scanner(br);
		  
		  
		  int rows = sc.nextInt();// get rows
		  int cols = sc.nextInt();// get columns
		  grid = new int[rows][cols];// make the grid the size
	      // initialize grid 
		  for(int i=0; i<rows;i++)// set grid to all 0's
		  {
			  for(int j=0;j<cols;j++)
				  grid[i][j] = 0;
		  }
	      //read the data from the file into the grid
		  
		  for(int i=0; i<rows;i++)
		  {
			  for(int j=0;j<cols;j++)
			  {
				  grid[i][j] = sc.nextInt();
			  }
		  }

	  } 
	  catch (IOException e) 
	  {// If it fails to read prints stack trace
			e.printStackTrace();
	  }
      
  }
  
  /**
   * @return the min value in the entire grid
   */
  public int findMinValue()
  {
	  int min = Integer.MAX_VALUE; // set min to max integer value
	  for(int i=0; i<grid.length;i++)
	  {
		  for(int j=0;j<grid[i].length;j++)
		  {
			  if(grid[i][j] < min)
				  min = grid[i][j]; // set min to new min
		  }
	  }
	  return min;
  }
  /**
   * @return the max value in the entire grid
   */
  public int findMaxValue()
  {
	  int max = Integer.MIN_VALUE; // set max to min integer value
	  for(int i=0; i<grid.length;i++)
	  {
		  for(int j=0;j<grid[i].length;j++)
		  {
			  if(grid[i][j] > max)
				  max = grid[i][j];// update max
		  }
	  }
	  return max;
  }
  
  /**
   * @param col the column of the grid to check
   * @return the index of the row with the lowest value in the given col for the grid
   */
  public  int indexOfMinInCol(int col)
  {
	  int min = Integer.MAX_VALUE; // set min to max integer value
	  int returnVal = -1;	// return index of lowest value
	  
	  for(int i=0; i<grid.length;i++)
	  {
		  if(grid[i][col] < min)
		  {
			  min = grid[i][col];	// update min value
			  returnVal = i;		// update index of min value
		  }
	  }
	  return returnVal;
  }

  /**
   * Draws the grid using the given Graphics object.
   * Colors should be grayscale values 0-255, scaled based on min/max values in grid
   */
  public void drawMap(Graphics g)
  {
	  int max = findMaxValue();
	  int min = findMinValue();
	  // Next 2 variables used to calculate the scaling for the 255 RGB scale compared to
	  // our current data ranges.
	  int dif = max-min;
	  double div = (dif/255)+1;	// This is the divisor factor to fix scaling.
	  for(int row=0; row<grid.length;row++)
	  {
		  for(int col=0;col<grid[row].length;col++)
		  {
			  double c = (grid[row][col] - min) / div;    //calculate the grayscale value
			  g.setColor(new Color((int)c, (int)c, (int)c));    // set all 3 of the RGB colors to be the same 0..255 value

			  // While data was stored as row,col, the graphing expects it to come in as col,row, so reverse it here:
			  g.fillRect(col,row,1,1);         // Draw a 1x1 rectangle corresponding to row,col   
		  }
	  }


  }

   /**
   * Find a path from West-to-East starting at given row.
   * Choose a forward step out of 3 possible forward locations, using greedy method described in assignment.
   * @return the total change in elevation traveled from West-to-East
   */
  public int drawLowestElevPath(Graphics g, int row)
  {
    int accumulated = 0;
    int accumulator = 0;
    int maxCol = grid[row].length;
    int maxRow = grid.length;
	g.fillRect(0,row,1,1);         // Draw a 1x1 rectangle corresponding to row,col   

	for(int col = 0;col<maxCol - 1;)// Draws the next one so the last one is drawn before loops ends
    {
    	int currentEle = grid[row][col];
    	col++;
    	
    	int up = Integer.MAX_VALUE;
    	int forward = Math.abs(grid[row][col] - currentEle);
    	int down = Integer.MAX_VALUE;;
    	if(row > 0)
    		up = Math.abs(grid[row-1][col] - currentEle);
    	if(row < maxRow - 2)// Make sure doesn't fall off the bottom
    		down = Math.abs(grid[row+1][col] - currentEle);
    	
    	// Goes to the lowest elevation change
    	// In case of a 3-way tie defaults to up
    	// Otherwise it will choose between the lower of down and up, or up if those 2 are tied.
    	if(forward < down && forward < up)
    	{
    		accumulator = forward;
    	}
    	else if(down < up)
    	{
    		accumulator = down;
    		row = row+1;
    	}
    	else
    	{
    		accumulator = up;
    		row -= 1;
    	}
    	
		g.fillRect(col,row,1,1);         // Draw a 1x1 rectangle corresponding to row,col   
    	
		accumulated += accumulator;
    }
    return accumulated;
  }
  
  
 
  /**
   * @return the index of the starting row for the lowest-elevation-change path in the entire grid.
   */
  public int indexOfLowestElevPath(Graphics g)
  {
     int lowestRow = -1;		// Row with lowest accumulated elevation
     int lowestAccumulated = Integer.MAX_VALUE;	// Current lowest accumulated elevation
     
     for(int row = 0; row < grid.length;row++)
     {
    	 int accumulated = drawLowestElevPath(g,row);
    	 if(lowestAccumulated > accumulated)
    	 {
    		 lowestAccumulated = accumulated;	// Update lowest accumulation
    		 lowestRow = row;					// Update lowest row with lowest accumulation
    	 }
     }
     
     return lowestRow;	// Return row with lowest accumulation 
  
  }
  
  
  /**
  * Find a path from West-to-East starting at given row.
  * Choose a forward step out of 5 possible forward locations, using greedy method described in assignment.
  * @return the total change in elevation traveled from West-to-East
  */
 public int drawLowestElevPathModded(Graphics g, int row)
 {
   int accumulated = 0;
   int accumulator = 0;
   int maxCol = grid[row].length;
   int maxRow = grid.length;

	g.fillRect(0,row,1,1);         // Draw a 1x1 rectangle corresponding to row,col   

   for(int col = 0;col<maxCol - 2;)// Draws the next one so the last one is drawn before loops ends
   {
   	int currentEle = grid[row][col];
   	col+=2;
   	
   	int upUp = Integer.MAX_VALUE;
   	int upForward = Integer.MAX_VALUE;
   	int forwardForward = Math.abs(grid[row][col] - currentEle);
   	int downForward = Integer.MAX_VALUE;;
   	int downDown = Integer.MAX_VALUE;
   	if(row > 1)
   	{
   		upUp = Math.abs(grid[row-2][col] - currentEle);
   	}
   	if(row > 0)
   	{
   		upForward = Math.abs(grid[row-1][col] - currentEle);
   	}
   	if(row < maxRow - 3)// Make sure doesn't fall off the bottom
   	{
   		downDown = Math.abs(grid[row+2][col] - currentEle);
   	}
   	if(row < maxRow - 2)// Make sure doesn't fall off the map
   	{
   		downForward = Math.abs(grid[row+1][col] - currentEle);
   	}
    // Goes to the lowest elevation change
	// if there is any tie it will prioritize as follows:
	// upUp -> upForward -> downForward -> downDown -> forwardForward
   	// so in any tie with forwardFoward, it will never go forwardForward
   	// in any tie with upUp it will always go upUp.
	
   	if(forwardForward < upUp && forwardForward < upForward &&
   	   forwardForward < downForward && forwardForward < downDown)
   	{
   		accumulator = forwardForward;
   		g.fillRect(col-1,row,1,1);         // Draw a 1x1 rectangle corresponding to row,col   
   	}
   	else if(downDown < downForward && downDown < upUp && downDown < upForward)
   	{
   		accumulator = downDown;
   		row += 2;
   		g.fillRect(col-1,row-1,1,1);         // Draw a 1x1 rectangle corresponding to row,col   
   	}
   	else if(downForward < upUp && downForward < upForward)
   	{
   		accumulator = downForward;
   		row += 1;
   		g.fillRect(col-1,row,1,1);         // Draw a 1x1 rectangle corresponding to row,col   
   		
   	}
   	else if(upForward < upUp)
   	{
   		accumulator = upForward;
   		row -= 1;
   		g.fillRect(col-1,row,1,1);         // Draw a 1x1 rectangle corresponding to row,col   
   	}
   	else
   	{
   		accumulator = upUp;
   		row -= 2;
   		g.fillRect(col-1,row+1,1,1);         // Draw a 1x1 rectangle corresponding to row,col 

   	}
   	
	g.fillRect(col,row,1,1);         // Draw a 1x1 rectangle corresponding to row,col 

	accumulated += accumulator;
   }
   return accumulated;
 }
 
 
 /**
  * @return the index of the starting row for the lowest-elevation-change path in the entire grid using modded method.
  */
 public int indexOfLowestElevPathModded(Graphics g)
 {
    int lowestRow = -1;		// Row with lowest accumulated elevation
    int lowestAccumulated = Integer.MAX_VALUE;	// Current lowest accumulated elevation
    
    for(int row = 0; row < grid.length;row++)
    {
   	 int accumulated = drawLowestElevPathModded(g,row);
   	 if(lowestAccumulated > accumulated)
   	 {
   		 lowestAccumulated = accumulated;	// Update lowest accumulation
   		 lowestRow = row;					// Update lowest row with lowest accumulation
   	 }
    }
    
    return lowestRow;	// Return row with lowest accumulation 
 
 }
 
}// End public class MapDataDrawer