package Program2;

/*
 * Usman Siddiqui
 * usiddi4 
 * CS 342 UIC Fall 2016
 * 
 * Author ID: 1325S
 * 
 * Given a map and elevations figure out the lowest elevation changes to travel through
 * given a starting row and comparing elevations to the next 3 in front of it.
 * 
 * current location X, possible destination D1, D2, D3
 * 		   Elevation change
 * 		D1 3
 * X	D2 4
 * 		D3 2
 * 
 * like so it would choose to go to D3 because the elevation change is the lowest.
 * This is called the Greedy Path Method
 * 
 * Then find the lowest elevation change overall using this method by comparing each 
 * elevation change per row finding the lowest elevation path determined by starting
 * row location.
 * 
 * With the modded method we now look further ahead
 * current location X, possible destination UU, UF, FF, DF, DD
 * 
 * 			UU 16
 * 		U 	UF 9 
 * X	F 	FF 8
 * 		D 	DF 2
 * 			DD 7
 * 
 * Now it would choose to go to DF and write a path with D and DF since that is the
 * smallest elevation change.
 * 
 * We again do the same design as before where we look at every row and find the
 * absolute minimum distance in regards to starting row. 
 */
import java.awt.*;

public class Driver
{
    
    public static void main(String[] args){
        
        //construct DrawingPanel, and get its Graphics context
        DrawingPanel panel = new DrawingPanel(844, 480);
        Graphics g = panel.getGraphics();
        
        //Test Step 1 - construct mountain map data
        MapDataDrawer map = new MapDataDrawer("NevadaToCalifornia.txt");
        
        //Test Step 2 - min, max, minRow in col
        int min = map.findMinValue();
        System.out.println("Min value in map: "+min);
        
        int max = map.findMaxValue();
        System.out.println("Max value in map: "+max);
        
        int minRow = map.indexOfMinInCol(0);
        System.out.println("Row with lowest val in col 0: "+minRow);
        
        //Test Step 3 - draw the map
        map.drawMap(g);
        
        g.setColor(Color.RED);
        int bestRow = map.indexOfLowestElevPath(g);
        
        //map.drawMap(g); //use this to get rid of all red lines
        
        //Lowest of all
        int bestRowM = map.indexOfLowestElevPathModded(g);
        map.drawMap(g);
        
        //Test Step 4 - draw a greedy path
        g.setColor(Color.RED); //can set the color of the 'brush' before drawing, then method doesn't need to worry about it
        int totalChange = map.drawLowestElevPath(g, minRow); //use minRow from Step 2 as starting point
        System.out.println("Lowest-Elevation-Change Path starting at row:\t\t"+minRow+"\nand gives a total change of:\t\t"+totalChange);
        
        //Test Step 5 - draw the best path
        g.setColor(Color.GREEN); //set brush to green for drawing best path
        totalChange = map.drawLowestElevPath(g, bestRow);
        System.out.println("The Lowest-Elevation-Change Path starts at row:\t\t"+bestRow+"\nand gives a total change of:\t\t"+totalChange);
        
        g.setColor(Color.BLUE);//set color to blue for most optimal
        totalChange = map.drawLowestElevPathModded(g,bestRowM);
        System.out.println("The Lowest-Elevation-Change(M) Path starts at row:\t"+bestRowM+"\nand gives a total change of:\t\t"+totalChange);

        
    }


}
