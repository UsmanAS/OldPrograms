I think everything is working fine, in my own implementation I forgot to include some parts in my algorithm
which makes is slower than it should be. Also I did not break things into functions because I thought it would
overcomplicate things (Such as my if statements I had them changing the rows and drawing which would be 
possible in functions, but then it would make it messy, not sure if I should have put it into a function or
not to be honest). 

So I have a question, if I were to break my if statements into a function I would have to pass ~10 parameters,
should I make it into a function or leave it as is?